#ifndef MASCOTA_H_INCLUDED
#define MASCOTA_H_INCLUDED
typedef struct
{
    int idMascota;
    char nombre[20];
    int idTipo;
    int idColor;
    int edad;
    int isEmpty;
}eMascota;
int modificarMascota(eMascota listaMascotas[],int tam,eTipo listaTipos[],int tamt,eColor listaColores[],int tamc,eServicio listaServicio[],int tams);
int hardcodearMascotas(eMascota mascotasLista[],int tam,int cant);
int inicializarMascotas(eMascota mascotasLista[], int tam);
int buscarLibre(eMascota listaMascotas[], int tam);
int altaMascotas(eMascota listaMascotas[],int tam,eTipo listaTipos[],int tamt,eColor listaColores[],int tamc,eServicio listaServicio[],int tams,int proximoId);
void mostrarMascota(eMascota unaMascota,eTipo listaTipos[],int tamt,eColor listaColores[],int tamc);
void mostrarMascotas(eMascota listaMascota[],int tam,eTipo listaTipos[],int tamt,eColor listaColores[],int tamc,eServicio listaServicio[],int tams);
int buscarMascota(eMascota listaMascotas[],int tam,int id);
int subMenu();
int bajaMascota(eMascota listaMascotas[],int tam,eTipo listaTipos[],int tamt,eColor listaColores[],int tamc,eServicio listaServicio[],int tams);


#endif // MASCOTA_H_INCLUDED
