#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "color.h"
#include "fecha.h"
#include "tipo.h"
#include "servicio.h"
#include "trabajo.h"
#include "mascota.h"

void mostrarTipos(eTipo listaTipos[],int tam)
{
    printf("  ****  Listado De Tipos ****  \n");
    printf("     ID          Descripcion      \n");
    printf("-----------------------------------------\n");

    for(int i =0 ; i < tam ; i++)
    {
       mostrarTipo(listaTipos[i]);
    }
    printf("\n\n");
}
void mostrarTipo(eTipo tipo)
{
    printf("  %d  %s \n",tipo.id,tipo.descripcionTipo);
}
int validarIdTipo(eTipo listaTipos[],int tam,int id)
{
    int esValido=0;
    for(int i=0;i<tam;i++)
    {
        if(listaTipos[i].id==id)
        {
            esValido=1;
            break;
        }
    }
    return esValido;
}
int cargarDescripcionTipo(eTipo listaTipos[],int tam,int id,char descripcion[])
{
    int error=1;
    if(listaTipos!=NULL && tam>0 && id >0 && descripcion!= NULL)
    {
        for(int i=0;i<tam;i++)
        {
            if(listaTipos[i].id==id)
            {
                strcpy(descripcion,listaTipos[i].descripcionTipo);
                error=0;
                break;
            }
        }
    }

    return error;
}

