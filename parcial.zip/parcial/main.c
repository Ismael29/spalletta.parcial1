#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "color.h"
#include "fecha.h"
#include "tipo.h"
#include "servicio.h"
#include "trabajo.h"
#include "mascota.h"
#define TAM 10
#define TAMT 5
#define TAMC 5
#define TAMS 3
int menu();


int main()
{
    int proximoId=0;
    eMascota listaMascotas[TAM];
    eTipo listaTipos[TAMT]={
        {1000,"Ave"},
        {1001,"Perro"},
        {1002,"Gato"},
        {1003,"Roedor"},
        {1004,"Pez"}
    };
    eColor listaColores[TAMC]={
        {5000,"Negro"},
        {5001,"Blanco"},
        {5002,"Gris"},
        {5003,"Rojo"},
        {5004,"Azul"}

        };
    eServicio listaServicio[TAMS]={
        {20000,"Corte",250},
        {20001,"Desparacitado",300},
        {20003,"Castrado",400}
    };

    int continuar=15;
    char confirmar;


     int rta;
    /*
     if(inicializarMascotas(listaMascotas,TAM)==0)
    {
        printf("TODO OK");
    }
    else
    {
        printf("TODO MAl");
    }
*/
    proximoId+=hardcodearMascotas(listaMascotas,TAM,10);
    do
    {
        //system("cls");
        switch(menu())
        {
        case 1:
            /*
            if(altaMascotas(listaMascotas,TAM,listaTipos,TAMT,listaColores,TAMC,listaServicio,TAMS,proximoId)==0)
            {
                proximoId++;
                printf("Alta Exitosa");
            }
            else
            {
                printf("No se pudo realizar el alta");
            }
            */
            break;
        case 2:
            rta=modificarMascota(listaMascotas,TAM,listaTipos,TAMT,listaColores,TAMC,listaServicio,TAMS);
            if(rta==0)
            {
                printf("Se modifico con exito\n");
            }
            else if(rta==2)
            {

                printf("Modificacion Cancelada por el usuario\n");
            }
            else
            {
                printf("Error en la Modificaicon\n");
            }

            break;
        case 3:
            rta=bajaMascota(listaMascotas,TAM,listaTipos,TAMT,listaColores,TAMC,listaServicio,TAMS);
            if(rta==0)
            {
                printf("Baja Exitosa\n");
            }
            else if(rta==2)
            {
                printf("Baja Cancelada por el usuario\n");
            }
            else
            {
                printf("Error en la baja\n");
            }
            break;
        case 4:
            mostrarMascotas(listaMascotas,TAM,listaTipos,TAMT,listaColores,TAMC,listaServicio,TAMS);
            break;
        case 15:
            system("cls");
            printf("Seguro que quiere salir?: s/n \n ");
            fflush(stdin);
            scanf("%c", &confirmar);
            confirmar = tolower(confirmar);
            if(confirmar == 's')
            {
                continuar= 'n';
            }
            break;
        }
    }
    while(continuar==15);
}

int menu()
{

    int opcion;
    //system("cls");
    printf("\t\t\t******************ABM PARCIAL 1**********************\n");
    printf("\t\t\t****************************************************\n");
    printf("\t\t\t****************************************************\n\n");
    printf("\t\t\t1)     Alta\n");
    printf("\t\t\t2)     Baja\n");
    printf("\t\t\t3)     Modificacion\n");
    printf("\t\t\t4)     Listar\n");
    printf("\t\t\t15)    Salir\n\n\n");
    printf("\n\nIngrese Opcion: ");
    fflush(stdin);
    scanf("%d",&opcion);
    while(isalpha(opcion)!=0)
    {
        printf("Error Ingrese un numero...\n");
        fflush(stdin);
        printf("\n\nIngrese Opcion: ");
        scanf("%d",&opcion);
    }
    return opcion;
}

int validacionDeString(char name[])
{

    for(int i=0 ; i<strlen(name); i++)
    {
        if(!((name[i]>=65 && name[i]<=90) || (name[i]>=97 && name[i]<=122)))
        {
            printf("Solo ingresa letras!!\n");
            return 0;
        }
    }
    return 1;
}


