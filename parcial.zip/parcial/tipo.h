#ifndef TIPO_H_INCLUDED
#define TIPO_H_INCLUDED
typedef struct
{
    int id;
    char descripcionTipo[20];

}eTipo;
void mostrarTipos(eTipo listaTipos[],int tam);
void mostrarTipo(eTipo tipo);
int validarIdTipo(eTipo listaTipos[],int tam,int id);
int cargarDescripcionTipo(eTipo listaTipos[],int tam,int id,char descripcion[]);

#endif // TIPO_H_INCLUDED
