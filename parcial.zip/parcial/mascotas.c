#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "color.h"
#include "fecha.h"
#include "tipo.h"
#include "servicio.h"
#include "trabajo.h"
#include "mascota.h"
#include "datastoreparcial.h"
int inicializarMascotas(eMascota mascotasLista[], int tam)
{
    int error= 1 ;

    if(mascotasLista!= NULL && tam > 0 )
    {
        for(int i=0; i < tam ; i++)
        {
            mascotasLista[i].isEmpty = 1;
            error=0;
        }

    }
    return error;
}

int hardcodearMascotas(eMascota mascotasLista[],int tam,int cant)
{
    int retorno=-1;
    if(mascotasLista!=NULL && tam>0 && cant<=tam)
    {
        retorno=0;
        for(int i=0; i<cant; i++)
        {
            mascotasLista[i].idColor=idColorHardCore[i];
            strcpy(mascotasLista[i].nombre,nombresHardCode[i]);
            mascotasLista[i].idMascota=idHardCore[i];
            mascotasLista[i].edad=edadHardCore[i];
            mascotasLista[i].idTipo=idTipoHardCore[i];
            retorno++;
        }
    }
    return retorno;
}
/*
int altaMascotas(eMascota listaMascotas[],int tam,eTipo listaTipos[],int tamt,eColor listaColores[],int tamc,eServicio listaServicio[],int tams,int proximoId)
{
    int error=1;
    eMascota nuevaMascota;
    int indice;
    int idTipo;
    if(listaMascotas!= NULL && listaTipos!=NULL && listaColores!=NULL  && listaServicio!=NULL && tam > 0 && tamt > 0 && tamc >0 && tams > 0 && proximoId>0) // validar vector con != de null
    {
        system("cls");
        printf("****ALTA Mascota****\n\n");
        indice=buscarLibre(listaMascotas,tam);
        if(indice==-1)
        {
            printf("Sistema Completo.");
        }
        else
        {
            nuevaMascota.idMascota=proximoId;
            nuevaMascota.isEmpty=0;

            printf("Ingrese nombre: ");
            fflush(stdin);
            gets(nuevaMascota.nombre);

            printf("Ingrese edad: ");
            scanf("%d",&nuevaMascota.edad);


            printf("-------------------------------------------");
            system("cls");
            fflush(stdin);
            mostrarTipos(listaMascotas,tam);
            printf("Ingrese id tipo:  ");
            scanf("%d",&idTipo);
            while(validarIdTipo(listaMascotas,tam,idTipo)==0)
            {

                printf("Id Invalido...Ingrese id deporte: ");
                scanf("%d",&idTipo);
            }
           nuevaMascota.idTipo=idTipo;
           listaMascotas[indice]=nuevaMascota;

            error=0;
        }
    }
    return error;
}
*/
int buscarLibre(eMascota listaMascotas[], int tam)
{
    int indice=-1;

    for(int i=0 ; i<tam; i++)
    {
        if(listaMascotas[i].isEmpty==1)
        {
            indice=i;
            break;
        }
    }
    return indice;
}

int modificarMascota(eMascota listaMascotas[],int tam,eTipo listaTipos[],int tamt,eColor listaColores[],int tamc,eServicio listaServicio[],int tams)
{
    int error=1;
    int indice;
    int id;
    char confirma;
    eTipo nuevoTipo;
    int nuevaEdad;
    if(listaMascotas!= NULL && tam > 0) // validar vector con != de null
    {
        system("cls");
        printf("*** Modificar Mascota***");
        mostrarMascotas(listaMascotas,tam,listaTipos,tamt,listaColores,tamc,listaServicio,tams);
        printf("Ingrese id");
        scanf("%d", &id);
        indice=buscarMascota(listaMascotas,tam,id);
        if(indice==-1)
        {
            printf("No hay ninguna Mascota con ese id\n");
        }
        else
        {
            switch(subMenu())
            {
            case 1:
                printf("Ingrese nuevo tipo:  ");
                scanf("%d",&nuevoTipo.id);
                mostrarTipo(nuevoTipo);
                printf("Confirma Tipo??");
                fflush(stdin);
                scanf("%c", &confirma);
                if(confirma =='s')
                {
                    listaMascotas[indice].idTipo=nuevoTipo.id;
                    error=0;
                }
                else
                {
                    error=2;
                }
                break;
            case 2:
                printf("Ingrese nueva edad:  ");
                scanf("%d",&nuevaEdad);
                printf("%d",nuevaEdad);
                printf("Confirma Tipo??");
                fflush(stdin);
                scanf("%c", &confirma);
                if(confirma =='s')
                {
                    listaMascotas[indice].edad=nuevaEdad;
                    error=0;
                }
                else
                {
                    error=2;
                }
                break;
            }
        }
    }
    return error;
}
    void mostrarMascotas(eMascota listaMascotas[],int tam,eTipo listaTipos[],int tamt,eColor listaColores[],int tamc,eServicio listaServicio[],int tams)
    {
        int flag=0;
        if(listaMascotas!= NULL && tam > 0 ) // validar vector con != de null
        {
            printf("*** Listado De Mascotas***\n\n");
            printf("      ID        Nombre          Tipo          Edad          \n");
            printf("-----------------------------------------------------------------------\n");
            for(int i =0 ; i < tam ; i++)
            {
                if(listaMascotas[i].isEmpty==0)
                {
                    mostrarMascota(listaMascotas[i],listaTipos,tamt,listaColores,tamc);
                    flag=1;
                }
            }
            if(flag==0)
            {
                printf("    No Hay mascotas En la Lista  \n\n");
            }
            else
            {
                printf("\n\n");
            }
        }
    }
    void mostrarMascota(eMascota unaMascota,eTipo listaTipos[],int tamt,eColor listaColores[],int tamc)
    {
        char descTipo[20];
        if(cargarDescripcionTipo(listaTipos,tamt,unaMascota.idTipo,descTipo)==0)
        {
            printf("       %d       %2s        %s         %d  \n",unaMascota.idMascota,unaMascota.nombre,descTipo,unaMascota.edad); //unaMascota.idColor
        }
        else
        {
            printf("tipo no corresponte\n");
        }
    }

    int buscarMascota(eMascota listaMascotas[],int tam,int id)
    {
        int indice=-1;

        for(int i=0 ; i<tam; i++)
        {
            if(listaMascotas[i].idMascota==id && listaMascotas[i].isEmpty==0)
            {
                indice=i;
                break;
            }
        }
        return indice;
    }

    int subMenu()
    {
        int opcion;
        printf("* * * Que quiere modificar? * * *\n\n\n");
        printf("1) Tipo.\n\n");
        printf("2) Edad.\n\n");
        printf("\n\nIngrese Opcion: ");
        fflush(stdin);
        scanf("%d",&opcion);

        return opcion;
    }

int bajaMascota(eMascota listaMascotas[],int tam,eTipo listaTipos[],int tamt,eColor listaColores[],int tamc,eServicio listaServicio[],int tams) //0 baja exitosa 1 problema 2 si cancelo la baja
{
    int error=-1;
    int indice;
    int id;
    char confirma;
    if(listaMascotas!= NULL && tam > 0 ) // validar vector con != de null
    {
        system("cls");
        printf("*** Baja Mascota***");
        mostrarMascotas(listaMascotas,tam,listaTipos,tamt,listaColores,tamc,listaServicio,tams);
        printf("Ingrese id");
        scanf("%d", &id);

        indice=buscarMascota(listaMascotas,tam,id);
        if(indice==-1)
        {
            printf("No hay ninguna mascota con ese id\n");

        }
        else
        {
            printf("Confirma baja?");
            fflush(stdin);
            scanf("%c", &confirma);
            if(confirma =='s')
            {
                listaMascotas[indice].isEmpty=1;
                error=0;
            }
            else
            {
                error=2;
            }
        }
    }
    return error;
}
