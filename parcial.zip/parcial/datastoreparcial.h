#include "fecha.h"
#ifndef DATASTOREPARCIAL_H_INCLUDED
#define DATASTOREPARCIAL_H_INCLUDED

char nombresHardCode[][20]=
{
    "Pelusa",
    "Muelitas",
    "BolaDenieve",
    "Leo",
    "Miguel",
    "Bigotes",
    "Firulais",
    "Gaston",
    "Teo",
    "Santa"
};

int idHardCore[]={1,2,3,4,5,6,7,8,9,10};

float idTipoHardCore[]={1000,1001,1002,1003,1004,1000,1001,1002,1003,1004};

int idColorHardCore[]={5000,5001,5002,5003,5004,5000,5001,5002,5003,5004};

int edadHardCore[]={1,2,3,4,5,1,2,3,4,5};











#endif // DATASTOREPARCIAL_H_INCLUDED
