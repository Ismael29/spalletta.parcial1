#include "fecha.h"
#include <stdio.h>

void mostrarFecha(eFecha fecha)
{
    printf("Fecha: %02d/%02d/%d\n",fecha.dia,fecha.mes,fecha.anio);
}
